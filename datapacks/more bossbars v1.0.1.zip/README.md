# More Bossbars Data Pack for Minecraft

This Data Pack adds bossbars (like the ones that the Ender Dragon and the Wither Boss have) to minibosses in-game.

Minibosses included:
  - Elder Guardian
  - Warden
  - Piglin Brute

Coming in future updates:
  - Evoker

Only one bar can be displayed for each miniboss type at any one time. This means that if you encounter more than one evoker, only one bar will show, all for all the other minibosses.
