# The Other Side
## A datapack made for Datapack Jam 3

*The Other Side makes use of the wonderful [TagLib](https://www.planetminecraft.com/data-pack/taglib/) datapack, by HeDeAn.*
